<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Sync</title>
</head>
<body>
    <h1>Sync Data from Server</h1>
    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <form action="<?php echo e(route('sync-data')); ?>" method="GET">
        <button type="submit">Sync Data</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\bapa\resources\views/index.blade.php ENDPATH**/ ?>